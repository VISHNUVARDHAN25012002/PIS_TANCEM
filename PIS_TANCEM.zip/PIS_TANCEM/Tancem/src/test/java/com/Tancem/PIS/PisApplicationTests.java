package com.Tancem.PIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PisApplicationTests {

	@Test
	void contextLoads() {
	}

}
