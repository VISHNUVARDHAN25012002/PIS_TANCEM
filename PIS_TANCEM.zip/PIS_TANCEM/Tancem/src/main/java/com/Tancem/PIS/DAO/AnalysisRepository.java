package com.Tancem.PIS.DAO;

import com.Tancem.PIS.Model.Analysis;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnalysisRepository extends JpaRepository<Analysis, Long> {

}