package com.Tancem.PIS.Controller;

import com.Tancem.PIS.Model.Analysis;
import com.Tancem.PIS.Service.AnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/analyses")
public class AnalysisController {

    @Autowired
    private AnalysisService analysisService;

    @GetMapping
    public List<Analysis> getAllAnalyses() {
        return analysisService.getAllAnalyses();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Analysis> getAnalysisById(@PathVariable Long id) {
        Analysis analysis = analysisService.getAnalysisById(id);
        return new ResponseEntity<>(analysis, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<String> createAnalysis(@RequestBody Analysis analysis) {
        Analysis savedAnalysis = analysisService.createAnalysis(analysis);
        return new ResponseEntity<>("Analysis created successfully: " + savedAnalysis.toString(), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Analysis> updateAnalysis(@PathVariable Long id, @RequestBody Analysis analysis) {
        Analysis updatedAnalysis = analysisService.updateAnalysis(id, analysis);
        return new ResponseEntity<>(updatedAnalysis, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAnalysis(@PathVariable Long id) {
        analysisService.deleteAnalysis(id);
        return new ResponseEntity<>("Analysis deleted successfully", HttpStatus.NO_CONTENT);
    }
}
