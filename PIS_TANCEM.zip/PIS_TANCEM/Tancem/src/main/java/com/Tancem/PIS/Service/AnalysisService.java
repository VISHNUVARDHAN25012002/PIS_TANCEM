package com.Tancem.PIS.Service;

import com.Tancem.PIS.Model.Analysis;

import java.util.List;

public interface AnalysisService {

    List<Analysis> getAllAnalyses();
    Analysis getAnalysisById(Long id);
    Analysis createAnalysis(Analysis analysis);
    Analysis updateAnalysis(Long id, Analysis analysis);
    void deleteAnalysis(Long id);
}
