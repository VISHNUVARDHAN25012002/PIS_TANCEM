package com.Tancem.PIS.ServiceImp;

import com.Tancem.PIS.DAO.AnalysisRepository;
import com.Tancem.PIS.Model.Analysis;
import com.Tancem.PIS.Service.AnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AnalysisServiceImp implements AnalysisService {

    @Autowired
    public AnalysisRepository analysisRepository;

    @Override
    public List<Analysis> getAllAnalyses() {
        return analysisRepository.findAll();
    }

    @Override
    public Analysis getAnalysisById(Long id) {
        Optional<Analysis> analysis = analysisRepository.findById(id);
        return analysis.orElseThrow(() -> new RuntimeException("Analysis not found with id: " + id));
    }

    @Override
    public Analysis createAnalysis(Analysis analysis) {
        return analysisRepository.save(analysis);
    }

    @Override
    public Analysis updateAnalysis(Long id, Analysis analysis) {
        if (!analysisRepository.existsById(id)) {
            throw new RuntimeException("Analysis not found with id: " + id);
        }
        analysis.setId(id);
        return analysisRepository.save(analysis);
    }

    @Override
    public void deleteAnalysis(Long id) {
        if (!analysisRepository.existsById(id)) {
            throw new RuntimeException("Analysis not found with id: " + id);
        }
        analysisRepository.deleteById(id);
    }
}
